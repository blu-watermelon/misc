package net.booden.mobiletictactoe;

public class MobileTicTacToeClient implements IMobileTicTacToePlayType, IReciever {
   private final char you = 'o';
   private final char opponent = 'x';
   private final int keyOffset = 49;
   private MobileTicTacToeGame game;
   private IClient client;

   public MobileTicTacToeClient(IClient clnt) {
      if (clnt != null) {
         this.client = clnt;
         this.client.setReciever(this, 1);
      }

   }

   public void dispose() {
      if (this.client != null && this.client.isConnected()) {
         this.client.disconnect();
         this.client = null;
      }

   }

   public void readKey(int keyCode) {
      int position = keyCode - 49;
      this.processMove(position);
   }

   public void readPointer(int areaNumber) {
      if (this.game.isGameEnd()) {
         this.processMove(-54);
      } else {
         this.processMove(areaNumber);
      }

   }

   private void processMove(int pos) {
      if (this.game != null && (this.game.getCurrentPlayer() == 'o' || this.game.isGameEnd() || this.client == null || !this.client.isConnected())) {
         char move = Integer.toString(pos).charAt(0);
         if (!this.game.isGameEnd() && pos >= 0 && pos <= 8 && this.game.move(pos) && this.client != null && this.client.isConnected()) {
            this.sendMove(move);
         }

         if (this.game.isGameEnd() && pos == -54) {
            if (this.client != null && this.client.isConnected()) {
               this.sendMove('9');
            }

            this.game.initGame();
         }
      }

   }

   public void recieve(char[] value) {
      try {
         String val = String.valueOf(value);
         int position = Integer.parseInt(val);
         if (this.game != null && (this.game.getCurrentPlayer() == 'x' || this.game.isGameEnd())) {
            if (!this.game.isGameEnd() && position >= 0 && position <= 8) {
               this.game.move(position);
            }

            if (this.game.isGameEnd() && position == 9) {
               this.game.initGame();
            }
         }
      } catch (NumberFormatException var4) {
      }

   }

   private void sendMove(char move) {
      this.client.send(new char[]{move});
   }

   public String getStatus() {
      return this.client != null && this.client.isConnected() ? "Connected" : "Disconnected";
   }

   public String getPlay() {
      if (this.game != null && this.game.isGameEnd()) {
         if (this.client != null && this.client.isConnected()) {
            if (this.game.getWinner() == 'o') {
               return "You win";
            } else {
               return this.game.getWinner() == 'x' ? "You lose" : "No winner this time!";
            }
         } else if (this.game.getWinner() == 'x') {
            return "X wins";
         } else {
            return this.game.getWinner() == 'o' ? "O wins" : "No winner this time!";
         }
      } else if (this.game != null) {
         if (this.client != null && this.client.isConnected()) {
            return this.game.getCurrentPlayer() == 'o' ? "Your move" : "Wait for opponents move";
         } else {
            return "Local play enabled";
         }
      } else {
         return "Client play enabled";
      }
   }

   public void setGame(MobileTicTacToeGame game) {
      this.game = game;
   }

   public void notifyConnected() {
      this.game.startFirstGame();
   }

   public void notifyDisconnected() {
      this.client = null;
      this.game.initGame();
   }
}

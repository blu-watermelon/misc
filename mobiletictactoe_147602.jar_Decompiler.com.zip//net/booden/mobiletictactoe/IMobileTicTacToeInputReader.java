package net.booden.mobiletictactoe;

public interface IMobileTicTacToeInputReader {
   void readKey(int var1);

   void readPointer(int var1);
}

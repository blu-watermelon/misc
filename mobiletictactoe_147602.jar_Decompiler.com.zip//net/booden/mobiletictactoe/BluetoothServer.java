package net.booden.mobiletictactoe;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Date;
import javax.bluetooth.UUID;
import javax.microedition.io.Connector;
import javax.microedition.io.StreamConnection;
import javax.microedition.io.StreamConnectionNotifier;

public class BluetoothServer implements IService, Runnable {
   private StreamConnectionNotifier streamConnNotifier;
   private StreamConnection connection;
   private InputStreamReader iReader;
   private OutputStreamWriter oWriter;
   private Thread startThread;
   private String uuid;
   private String serviceName;
   private boolean connected = false;
   private IReciever reciever;
   private int numChars;
   private InputStream inStream;
   private OutputStream outStream;
   private char[] exit;
   private char[] polling;
   private Date pollingTime;

   public BluetoothServer(String uuid, String serviceName) {
      this.uuid = uuid;
      this.serviceName = serviceName;
      this.startThread = new Thread(this);
      this.startThread.start();
   }

   public boolean isConnected() {
      return this.connected;
   }

   public void setReciever(IReciever reciever, int numChars) {
      this.exit = new char[numChars];

      int i;
      for(i = 0; i < numChars; ++i) {
         this.exit[i] = 'x';
      }

      this.polling = new char[numChars];

      for(i = 0; i < numChars; ++i) {
         this.polling[i] = '?';
      }

      this.reciever = reciever;
      this.numChars = numChars;
   }

   public void send(char[] value) {
      try {
         this.oWriter.write(value);
         this.oWriter.flush();
      } catch (IOException var3) {
         this.setDisconnected();
      }

   }

   public void disconnect() {
      if (this.connected) {
         this.connected = false;
         if (this.streamConnNotifier != null) {
            try {
               this.streamConnNotifier.close();
            } catch (IOException var8) {
            }

            this.streamConnNotifier = null;
         }

         if (this.connection != null) {
            try {
               this.send(this.exit);
               this.connection.close();
            } catch (IOException var7) {
            }

            this.connection = null;
         }

         if (this.inStream != null) {
            try {
               this.inStream.close();
            } catch (IOException var6) {
            }

            this.inStream = null;
         }

         if (this.outStream != null) {
            try {
               this.outStream.close();
            } catch (IOException var5) {
            }

            this.outStream = null;
         }

         if (this.iReader != null) {
            try {
               this.iReader.close();
            } catch (IOException var4) {
            }

            this.iReader = null;
         }

         if (this.oWriter != null) {
            try {
               this.oWriter.close();
            } catch (IOException var3) {
            }

            this.oWriter = null;
         }

         if (this.startThread != null && this.startThread.isAlive()) {
            try {
               this.startThread.join();
            } catch (InterruptedException var2) {
            }
         }
      }

      System.gc();
   }

   public void run() {
      try {
         this.waitForConnection();
         this.inStream = this.connection.openInputStream();
         this.iReader = new InputStreamReader(this.inStream);
         this.outStream = this.connection.openOutputStream();
         this.oWriter = new OutputStreamWriter(this.outStream);
         this.connected = true;
         this.setConnected();
         this.pollingTime = new Date();
         this.readMoves();
      } catch (IOException var2) {
         this.setDisconnected();
      }

   }

   private void setConnected() {
      Thread t = new Thread(new Runnable() {
         public void run() {
            BluetoothServer.this.reciever.notifyConnected();
         }
      });
      t.start();
   }

   private void setDisconnected() {
      Thread t = new Thread(new Runnable() {
         public void run() {
            BluetoothServer.this.disconnect();
            BluetoothServer.this.reciever.notifyDisconnected();
         }
      });
      t.start();
   }

   private void waitForConnection() throws IOException {
      UUID SERVICE = new UUID(this.uuid, false);
      String connectionString = "btspp://localhost:" + SERVICE + ";name=" + this.serviceName;
      this.streamConnNotifier = (StreamConnectionNotifier)Connector.open(connectionString);

      try {
         this.connection = this.streamConnNotifier.acceptAndOpen();
      } finally {
         this.streamConnNotifier.close();
         this.streamConnNotifier = null;
      }

   }

   private void readMoves() {
      char[] cbuf = new char[this.numChars];

      while(this.connected) {
         try {
            if (this.iReader.ready()) {
               this.iReader.read(cbuf);
               if (this.arraysEquals(cbuf, this.exit)) {
                  this.setDisconnected();
                  return;
               }

               if (this.reciever != null && !this.arraysEquals(cbuf, this.polling)) {
                  this.reciever.recieve(cbuf);
               }

               this.pollingTime = new Date();
            } else {
               this.send(this.polling);
               if (this.pollingTime != null && this.pollingTime.getTime() < (new Date()).getTime() - 1500L) {
                  this.setDisconnected();
                  return;
               }

               Thread.sleep(100L);
               Thread.yield();
            }
         } catch (IOException var3) {
            this.setDisconnected();
         } catch (InterruptedException var4) {
         }
      }

   }

   private boolean arraysEquals(char[] one, char[] two) {
      if (one.length != two.length) {
         return false;
      } else {
         for(int i = 0; i < one.length; ++i) {
            if (one[i] != two[i]) {
               return false;
            }
         }

         return true;
      }
   }
}

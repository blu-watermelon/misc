package net.booden.mobiletictactoe;

public interface IMobileTicTacToeGUI {
   void update(char[] var1);

   void setStatus(String var1);

   void setPlay(String var1);

   void setKeyReader(IMobileTicTacToeInputReader var1);
}

package net.booden.mobiletictactoe;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.List;
import javax.microedition.midlet.MIDlet;

public class MobileTicTacToeMIDlet extends MIDlet implements CommandListener {
   private Command exitCommand = new Command("Exit", 7, 0);
   private Command menuCommand = new Command("Menu", 2, 0);
   private Command selectCommand = new Command("Ok", 2, 0);
   private List menu;
   private List devices;
   private IClient client;
   private boolean selectDevice = true;
   private String mtttserviceuuid = "26ED8DC056B711DE8A390800200C9A66";
   private MobileTicTacToeGame game;

   public MobileTicTacToeMIDlet() {
      String[] menuItems;
      if (supportsBluetooth()) {
         menuItems = new String[]{"Local Play", "Play Computer", "Wait for BT Connection", "Connect to BT Device"};
         this.menu = new List("MobileTicTacToe", 3, menuItems, (Image[])null);
      } else {
         menuItems = new String[]{"Local Play", "Play Computer"};
         this.menu = new List("MobileTicTacToe", 3, menuItems, (Image[])null);
      }

      this.menu.addCommand(this.exitCommand);
      this.menu.addCommand(this.selectCommand);
      this.menu.setCommandListener(this);
   }

   private static boolean supportsBluetooth() {
      try {
         Class.forName("javax.bluetooth.LocalDevice");
         return true;
      } catch (Throwable var1) {
         return false;
      }
   }

   public void startApp() {
      this.ShowMenu();
   }

   public void pauseApp() {
   }

   public void destroyApp(boolean unconditional) {
      if (this.game != null) {
         this.game.dispose();
         this.game = null;
         System.gc();
      }

   }

   public void commandAction(Command c, Displayable s) {
      if (c == this.exitCommand) {
         this.destroyApp(true);
         this.notifyDestroyed();
      } else if (c == this.menuCommand) {
         this.selectDevice = true;
         if (this.game != null) {
            this.game.dispose();
            this.game = null;
         }

         System.gc();
         this.ShowMenu();
      } else {
         switch(this.menu.getSelectedIndex()) {
         case 0:
            this.CreateCanvas(new MobileTicTacToeLocalPlay());
            break;
         case 1:
            this.CreateCanvas(new MobileTicTacToeComputerPlay());
            break;
         case 2:
            IService service = new BluetoothServer(this.mtttserviceuuid, "MobileTicTacToe Service");
            this.CreateCanvas(new MobileTicTacToeServer(service));
            break;
         case 3:
            BluetoothClient bt;
            if (this.selectDevice) {
               this.selectDevice = false;
               bt = new BluetoothClient(this.mtttserviceuuid);
               String[] dev = bt.discoverDevices();
               this.client = bt;
               this.devices = new List("Devices", 3, dev, (Image[])null);
               this.devices.addCommand(this.menuCommand);
               this.devices.addCommand(this.selectCommand);
               this.devices.setCommandListener(this);
               Display.getDisplay(this).setCurrent(this.devices);
            } else {
               this.selectDevice = true;
               bt = (BluetoothClient)this.client;
               bt.setDeviceIndex(this.devices.getSelectedIndex());
               this.CreateCanvas(new MobileTicTacToeClient(this.client));
            }
         }

      }
   }

   private void CreateCanvas(IMobileTicTacToePlayType playType) {
      Canvas c = new MobileTicTacToeMIDlet.CheckSize();
      int height = c.getHeight();
      int width = c.getWidth();
      Object mc;
      if (width > 144 && height > 194) {
         mc = new MobileTicTacToeCanvas();
      } else if (width > 108 && height > 147) {
         mc = new MobileTicTacToeSmallCanvas();
      } else {
         mc = new MobileTicTacToeTinyCanvas();
      }

      ((Canvas)mc).addCommand(this.exitCommand);
      ((Canvas)mc).addCommand(this.menuCommand);
      ((Canvas)mc).setCommandListener(this);
      Display.getDisplay(this).setCurrent((Displayable)mc);
      this.game = new MobileTicTacToeGame((IMobileTicTacToeGUI)mc, playType);
   }

   private void ShowMenu() {
      Display.getDisplay(this).setCurrent(this.menu);
   }

   private class CheckSize extends Canvas {
      private CheckSize() {
      }

      protected void paint(Graphics g) {
      }

      // $FF: synthetic method
      CheckSize(Object x1) {
         this();
      }
   }
}

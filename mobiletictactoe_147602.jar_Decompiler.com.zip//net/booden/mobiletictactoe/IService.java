package net.booden.mobiletictactoe;

public interface IService {
   boolean isConnected();

   void setReciever(IReciever var1, int var2);

   void send(char[] var1);

   void disconnect();
}

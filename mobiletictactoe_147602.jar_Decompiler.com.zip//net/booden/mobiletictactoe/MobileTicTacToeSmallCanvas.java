package net.booden.mobiletictactoe;

import java.io.IOException;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

public class MobileTicTacToeSmallCanvas extends Canvas implements IMobileTicTacToeGUI {
   private Image imgIcon;
   private Image imgX;
   private Image imgO;
   private char[] board = new char[9];
   private MobileTicTacToeSmallCanvas.Point[] pos = new MobileTicTacToeSmallCanvas.Point[9];
   private String status = "";
   private String play = "";
   private IMobileTicTacToeInputReader inputReader;
   private int leftMargin;
   private int topMargin;
   private static final int TL_ANCHOR = 20;

   public MobileTicTacToeSmallCanvas() {
      try {
         this.imgIcon = Image.createImage("/nttticon.png");
         this.imgX = Image.createImage("/xsmall.png");
         this.imgO = Image.createImage("/osmall.png");
      } catch (IOException var2) {
         throw new RuntimeException("Unable to load Image: " + var2);
      }

      this.initPoints();
   }

   protected void keyReleased(int keyCode) {
      if (this.inputReader != null) {
         this.inputReader.readKey(keyCode);
      }

   }

   public void pointerReleased(int x, int y) {
      int posX = x - this.leftMargin;
      int posY = y - this.topMargin;

      for(int i = 0; i < this.pos.length; ++i) {
         if (posX > this.pos[i].getX() && posX < this.pos[i].getX() + this.imgX.getWidth() && posY > this.pos[i].getY() && posY < this.pos[i].getY() + this.imgX.getHeight()) {
            this.inputReader.readPointer(i);
         }
      }

   }

   private void initPoints() {
      int x = 1;
      int y = 18;

      for(int i = 0; i < 9; ++i) {
         this.pos[i] = new MobileTicTacToeSmallCanvas.Point(x, y);
         x += 36;
         if (i == 2) {
            x = 1;
            y += 36;
         }

         if (i == 5) {
            x = 1;
            y += 36;
         }
      }

   }

   protected void paint(Graphics g) {
      this.leftMargin = (g.getClipWidth() - 108) / 2;
      this.topMargin = (g.getClipHeight() - 148) / 2;
      g.setColor(128, 128, 128);
      g.fillRect(0, 0, g.getClipWidth(), g.getClipHeight());
      g.setColor(8034272);
      g.fillRect(this.leftMargin, this.topMargin, 108, 16);
      g.drawImage(this.imgIcon, this.leftMargin, this.topMargin, 20);
      Font fontMedium = Font.getFont(0, 0, 8);
      g.setFont(fontMedium);
      g.setColor(255, 255, 255);
      g.drawString("MobileTicTacToe", this.leftMargin + 18, this.topMargin + 2, 20);
      g.fillRect(this.leftMargin + 0, this.topMargin + 16, 108, 108);
      g.setColor(0, 0, 0);
      g.drawRect(this.leftMargin + 0, this.topMargin + 16, 108, 108);
      g.drawLine(this.leftMargin + 0, this.topMargin + 52, this.leftMargin + 108, this.topMargin + 52);
      g.drawLine(this.leftMargin + 0, this.topMargin + 88, this.leftMargin + 108, this.topMargin + 88);
      g.drawLine(this.leftMargin + 36, this.topMargin + 16, this.leftMargin + 36, this.topMargin + 124);
      g.drawLine(this.leftMargin + 72, this.topMargin + 16, this.leftMargin + 72, this.topMargin + 124);

      for(int i = 0; i < 9; ++i) {
         if (this.board[i] == 'x') {
            g.drawImage(this.imgX, this.leftMargin + this.pos[i].getX(), this.topMargin + this.pos[i].getY(), 20);
         } else if (this.board[i] == 'o') {
            g.drawImage(this.imgO, this.leftMargin + this.pos[i].getX(), this.topMargin + this.pos[i].getY(), 20);
         }
      }

      g.setColor(255, 255, 255);
      g.drawString(this.status, this.leftMargin + 1, this.topMargin + 125, 20);
      g.drawString(this.play, this.leftMargin + 1, this.topMargin + 134, 20);
   }

   public void update(char[] board) {
      this.board = board;
      this.repaint();
   }

   public void setStatus(String status) {
      this.status = status;
   }

   public void setPlay(String play) {
      this.play = play;
   }

   public void setKeyReader(IMobileTicTacToeInputReader reader) {
      this.inputReader = reader;
   }

   private class Point {
      private int _x;
      private int _y;

      Point(int x, int y) {
         this._x = x;
         this._y = y;
      }

      public int getX() {
         return this._x;
      }

      public int getY() {
         return this._y;
      }
   }
}

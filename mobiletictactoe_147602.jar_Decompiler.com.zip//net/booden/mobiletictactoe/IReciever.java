package net.booden.mobiletictactoe;

public interface IReciever {
   void notifyConnected();

   void notifyDisconnected();

   void recieve(char[] var1);
}

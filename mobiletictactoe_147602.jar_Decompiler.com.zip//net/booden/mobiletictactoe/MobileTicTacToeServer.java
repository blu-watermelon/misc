package net.booden.mobiletictactoe;

public class MobileTicTacToeServer implements IMobileTicTacToePlayType, IReciever {
   private final char you = 'x';
   private final char opponent = 'o';
   private final int keyOffset = 49;
   private MobileTicTacToeGame game;
   private IService service;

   public MobileTicTacToeServer(IService svc) {
      if (svc != null) {
         this.service = svc;
         this.service.setReciever(this, 1);
      }

   }

   public void dispose() {
      if (this.service != null && this.service.isConnected()) {
         this.service.disconnect();
         this.service = null;
      }

   }

   public void readKey(int keyCode) {
      int position = keyCode - 49;
      this.processMove(position);
   }

   public void readPointer(int areaNumber) {
      if (this.game.isGameEnd()) {
         this.processMove(-54);
      } else {
         this.processMove(areaNumber);
      }

   }

   private void processMove(int pos) {
      if (this.game != null && (this.game.getCurrentPlayer() == 'x' || this.game.isGameEnd() || this.service == null || !this.service.isConnected())) {
         char move = Integer.toString(pos).charAt(0);
         if (!this.game.isGameEnd() && pos >= 0 && pos <= 8 && this.game.move(pos) && this.service != null && this.service.isConnected()) {
            this.sendMove(move);
         }

         if (this.game.isGameEnd() && pos == -54) {
            if (this.service != null && this.service.isConnected()) {
               this.sendMove('9');
            }

            this.game.initGame();
         }
      }

   }

   public void recieve(char[] value) {
      try {
         String val = String.valueOf(value);
         int position = Integer.parseInt(val);
         if (this.game != null && (this.game.getCurrentPlayer() == 'o' || this.game.isGameEnd())) {
            if (!this.game.isGameEnd() && position >= 0 && position <= 8) {
               this.game.move(position);
            }

            if (this.game.isGameEnd() && position == 9) {
               this.game.initGame();
            }
         }
      } catch (NumberFormatException var4) {
      }

   }

   private void sendMove(char move) {
      this.service.send(new char[]{move});
   }

   public String getStatus() {
      return this.service != null && this.service.isConnected() ? "Connected" : "Disconnected";
   }

   public String getPlay() {
      if (this.game != null && this.game.isGameEnd()) {
         if (this.service != null && this.service.isConnected()) {
            if (this.game.getWinner() == 'x') {
               return "You win";
            } else {
               return this.game.getWinner() == 'o' ? "You lose" : "No winner this time!";
            }
         } else if (this.game.getWinner() == 'x') {
            return "X wins";
         } else {
            return this.game.getWinner() == 'o' ? "O wins" : "No winner this time!";
         }
      } else if (this.game != null) {
         if (this.service != null && this.service.isConnected()) {
            return this.game.getCurrentPlayer() == 'x' ? "Your move" : "Wait for opponents move";
         } else {
            return "Local play enabled";
         }
      } else {
         return "Service play enabled";
      }
   }

   public void setGame(MobileTicTacToeGame game) {
      this.game = game;
   }

   public void notifyConnected() {
      this.game.startFirstGame();
   }

   public void notifyDisconnected() {
      this.service = null;
      this.game.initGame();
   }
}

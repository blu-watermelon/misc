package net.booden.mobiletictactoe;

public class MobileTicTacToeLocalPlay implements IMobileTicTacToePlayType {
   private final int keyOffset = 49;
   private MobileTicTacToeGame game;

   public void dispose() {
   }

   public void readKey(int keyCode) {
      int position = keyCode - 49;
      this.processMove(position);
   }

   public void readPointer(int areaNumber) {
      if (this.game.isGameEnd()) {
         this.processMove(-54);
      } else {
         this.processMove(areaNumber);
      }

   }

   private void processMove(int pos) {
      if (this.game != null && !this.game.isGameEnd() && pos >= 0 && pos <= 8) {
         this.game.move(pos);
      }

      if (this.game != null && this.game.isGameEnd() && pos == -54) {
         this.game.initGame();
      }

   }

   public String getStatus() {
      return "Disconnected";
   }

   public String getPlay() {
      if (this.game != null && this.game.isGameEnd()) {
         if (this.game.getWinner() == 'x') {
            return "X wins";
         } else {
            return this.game.getWinner() == 'o' ? "O wins" : "No winner this time!";
         }
      } else {
         return "Local play enabled";
      }
   }

   public void setGame(MobileTicTacToeGame game) {
      this.game = game;
   }
}

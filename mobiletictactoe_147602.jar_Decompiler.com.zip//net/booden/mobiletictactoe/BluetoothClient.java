package net.booden.mobiletictactoe;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Date;
import java.util.Vector;
import javax.bluetooth.DeviceClass;
import javax.bluetooth.DiscoveryAgent;
import javax.bluetooth.DiscoveryListener;
import javax.bluetooth.LocalDevice;
import javax.bluetooth.RemoteDevice;
import javax.bluetooth.ServiceRecord;
import javax.bluetooth.UUID;
import javax.microedition.io.Connector;
import javax.microedition.io.StreamConnection;

public class BluetoothClient implements IClient, Runnable, DiscoveryListener {
   private final Object lock = new Object();
   private Vector vecDevices = new Vector();
   private String connectionURL;
   private DiscoveryAgent agent;
   private int search;
   private StreamConnection streamConnection;
   private InputStreamReader iReader;
   private OutputStreamWriter oWriter;
   private Thread startThread;
   private String uuid;
   private boolean connected = false;
   private IReciever reciever;
   private int numChars;
   private int deviceIndex;
   private InputStream inStream;
   private OutputStream outStream;
   private char[] exit;
   private char[] polling;
   private Date pollingTime;

   public BluetoothClient(String uuid) {
      this.uuid = uuid;
   }

   public void setDeviceIndex(int index) {
      this.deviceIndex = index;
      this.startThread = new Thread(this);
      this.startThread.start();
   }

   public boolean isConnected() {
      return this.connected;
   }

   public void setReciever(IReciever reciever, int numChars) {
      this.exit = new char[numChars];

      int i;
      for(i = 0; i < numChars; ++i) {
         this.exit[i] = 'x';
      }

      this.polling = new char[numChars];

      for(i = 0; i < numChars; ++i) {
         this.polling[i] = '?';
      }

      this.reciever = reciever;
      this.numChars = numChars;
   }

   public void send(char[] value) {
      try {
         this.oWriter.write(value);
         this.oWriter.flush();
      } catch (IOException var3) {
         this.setDisconnected();
      }

   }

   public void disconnect() {
      if (this.connected) {
         this.connected = false;
         if (this.agent != null) {
            this.agent.cancelInquiry(this);
            this.agent.cancelServiceSearch(this.search);
            this.agent = null;
         }

         if (this.streamConnection != null) {
            try {
               this.send(this.exit);
               this.streamConnection.close();
            } catch (IOException var7) {
            }

            this.streamConnection = null;
         }

         if (this.inStream != null) {
            try {
               this.inStream.close();
            } catch (IOException var6) {
            }

            this.inStream = null;
         }

         if (this.outStream != null) {
            try {
               this.outStream.close();
            } catch (IOException var5) {
            }

            this.outStream = null;
         }

         if (this.iReader != null) {
            try {
               this.iReader.close();
            } catch (IOException var4) {
            }

            this.iReader = null;
         }

         if (this.oWriter != null) {
            try {
               this.oWriter.close();
            } catch (IOException var3) {
            }

            this.oWriter = null;
         }

         if (this.startThread != null && this.startThread.isAlive()) {
            try {
               this.startThread.join();
            } catch (InterruptedException var2) {
            }
         }
      }

      System.gc();
   }

   public void run() {
      try {
         if (!this.connectToDevice(this.deviceIndex)) {
            return;
         }

         this.outStream = this.streamConnection.openOutputStream();
         this.oWriter = new OutputStreamWriter(this.outStream);
         this.inStream = this.streamConnection.openInputStream();
         this.iReader = new InputStreamReader(this.inStream);
         this.connected = true;
         this.setConnected();
         this.pollingTime = new Date();
         this.readMoves();
      } catch (IOException var2) {
         this.setDisconnected();
      }

   }

   private void setConnected() {
      Thread t = new Thread(new Runnable() {
         public void run() {
            BluetoothClient.this.reciever.notifyConnected();
         }
      });
      t.start();
   }

   private void setDisconnected() {
      Thread t = new Thread(new Runnable() {
         public void run() {
            BluetoothClient.this.disconnect();
            BluetoothClient.this.reciever.notifyDisconnected();
         }
      });
      t.start();
   }

   public String[] discoverDevices() {
      String[] devices = new String[]{"No devices found"};

      try {
         LocalDevice localDevice = LocalDevice.getLocalDevice();
         this.agent = localDevice.getDiscoveryAgent();
         this.agent.startInquiry(10390323, this);

         try {
            synchronized(this.lock) {
               this.lock.wait();
            }
         } catch (InterruptedException var7) {
         }

         int deviceCount = this.vecDevices.size();
         if (deviceCount <= 0) {
            return devices;
         }

         devices = new String[deviceCount];

         for(int i = 0; i < deviceCount; ++i) {
            RemoteDevice remoteDevice = (RemoteDevice)this.vecDevices.elementAt(i);
            devices[i] = remoteDevice.getFriendlyName(true);
         }
      } catch (IOException var8) {
      }

      return devices;
   }

   private boolean connectToDevice(int index) {
      UUID SERVICE = new UUID(this.uuid, false);
      RemoteDevice remoteDevice = (RemoteDevice)this.vecDevices.elementAt(index);
      UUID[] uuidSet = new UUID[]{SERVICE};

      try {
         this.search = this.agent.searchServices((int[])null, uuidSet, remoteDevice, this);
      } catch (Exception var15) {
      }

      try {
         synchronized(this.lock) {
            this.lock.wait();
         }
      } catch (InterruptedException var14) {
         return false;
      }

      if (this.connectionURL == null) {
         return false;
      } else {
         boolean var6;
         try {
            this.streamConnection = (StreamConnection)Connector.open(this.connectionURL);
            return true;
         } catch (IOException var16) {
            var6 = false;
         } finally {
            this.agent = null;
         }

         return var6;
      }
   }

   private void readMoves() {
      char[] cbuf = new char[this.numChars];

      while(this.connected) {
         try {
            if (this.iReader.ready()) {
               this.iReader.read(cbuf);
               if (this.arraysEquals(cbuf, this.exit)) {
                  this.setDisconnected();
                  return;
               }

               if (this.reciever != null && !this.arraysEquals(cbuf, this.polling)) {
                  this.reciever.recieve(cbuf);
               }

               this.pollingTime = new Date();
            } else {
               this.send(this.polling);
               if (this.pollingTime != null && this.pollingTime.getTime() < (new Date()).getTime() - 1500L) {
                  this.setDisconnected();
                  return;
               }

               Thread.sleep(100L);
               Thread.yield();
            }
         } catch (IOException var3) {
            this.setDisconnected();
         } catch (InterruptedException var4) {
         }
      }

   }

   private boolean arraysEquals(char[] one, char[] two) {
      if (one.length != two.length) {
         return false;
      } else {
         for(int i = 0; i < one.length; ++i) {
            if (one[i] != two[i]) {
               return false;
            }
         }

         return true;
      }
   }

   public void deviceDiscovered(RemoteDevice btDevice, DeviceClass cod) {
      if (!this.vecDevices.contains(btDevice)) {
         this.vecDevices.addElement(btDevice);
      }

   }

   public void servicesDiscovered(int transID, ServiceRecord[] servRecord) {
      if (servRecord != null && servRecord.length > 0) {
         this.connectionURL = servRecord[0].getConnectionURL(0, false);
      }

      synchronized(this.lock) {
         this.lock.notify();
      }
   }

   public void serviceSearchCompleted(int transID, int respCode) {
      synchronized(this.lock) {
         this.lock.notify();
      }
   }

   public void inquiryCompleted(int discType) {
      synchronized(this.lock) {
         this.lock.notify();
      }
   }
}

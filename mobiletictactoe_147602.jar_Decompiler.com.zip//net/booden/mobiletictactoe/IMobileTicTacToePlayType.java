package net.booden.mobiletictactoe;

public interface IMobileTicTacToePlayType extends IMobileTicTacToeInputReader {
   void dispose();

   String getStatus();

   String getPlay();

   void setGame(MobileTicTacToeGame var1);
}

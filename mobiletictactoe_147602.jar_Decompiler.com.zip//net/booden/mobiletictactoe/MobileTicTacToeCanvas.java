package net.booden.mobiletictactoe;

import java.io.IOException;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

public class MobileTicTacToeCanvas extends Canvas implements IMobileTicTacToeGUI {
   private Image imgIcon;
   private Image imgX;
   private Image imgO;
   private char[] board = new char[9];
   private MobileTicTacToeCanvas.Point[] pos = new MobileTicTacToeCanvas.Point[9];
   private String status = "";
   private String play = "";
   private IMobileTicTacToeInputReader inputReader;
   private int leftMargin;
   private int topMargin;
   private static final int TL_ANCHOR = 20;

   public MobileTicTacToeCanvas() {
      try {
         this.imgIcon = Image.createImage("/nttticon.png");
         this.imgX = Image.createImage("/x.png");
         this.imgO = Image.createImage("/o.png");
      } catch (IOException var2) {
         throw new RuntimeException("Unable to load Image: " + var2);
      }

      this.initPoints();
   }

   protected void keyReleased(int keyCode) {
      if (this.inputReader != null) {
         this.inputReader.readKey(keyCode);
      }

   }

   public void pointerReleased(int x, int y) {
      int posX = x - this.leftMargin;
      int posY = y - this.topMargin;

      for(int i = 0; i < this.pos.length; ++i) {
         if (posX > this.pos[i].getX() && posX < this.pos[i].getX() + this.imgX.getWidth() && posY > this.pos[i].getY() && posY < this.pos[i].getY() + this.imgX.getHeight()) {
            this.inputReader.readPointer(i);
         }
      }

   }

   private void initPoints() {
      int x = 1;
      int y = 24;

      for(int i = 0; i < 9; ++i) {
         this.pos[i] = new MobileTicTacToeCanvas.Point(x, y);
         x += 48;
         if (i == 2) {
            x = 1;
            y += 47;
         }

         if (i == 5) {
            x = 1;
            y += 47;
         }
      }

   }

   protected void paint(Graphics g) {
      this.leftMargin = (g.getClipWidth() - 144) / 2;
      this.topMargin = (g.getClipHeight() - 195) / 2;
      g.setColor(128, 128, 128);
      g.fillRect(0, 0, g.getClipWidth(), g.getClipHeight());
      g.setColor(8034272);
      g.fillRect(this.leftMargin, this.topMargin, 144, 20);
      g.drawImage(this.imgIcon, this.leftMargin + 2, this.topMargin + 2, 20);
      Font fontMedium = Font.getFont(0, 0, 0);
      g.setFont(fontMedium);
      g.setColor(255, 255, 255);
      g.drawString("MobileTicTacToe", this.leftMargin + 20, this.topMargin + 3, 20);
      g.fillRect(this.leftMargin + 0, this.topMargin + 20, 144, 142);
      g.setColor(0, 0, 0);
      g.drawRect(this.leftMargin + 0, this.topMargin + 20, 144, 142);
      g.drawLine(this.leftMargin + 0, this.topMargin + 66, this.leftMargin + 144, this.topMargin + 66);
      g.drawLine(this.leftMargin + 0, this.topMargin + 116, this.leftMargin + 144, this.topMargin + 116);
      g.drawLine(this.leftMargin + 47, this.topMargin + 20, this.leftMargin + 47, this.topMargin + 162);
      g.drawLine(this.leftMargin + 96, this.topMargin + 20, this.leftMargin + 96, this.topMargin + 162);

      for(int i = 0; i < 9; ++i) {
         if (this.board[i] == 'x') {
            g.drawImage(this.imgX, this.leftMargin + this.pos[i].getX(), this.topMargin + this.pos[i].getY(), 20);
         } else if (this.board[i] == 'o') {
            g.drawImage(this.imgO, this.leftMargin + this.pos[i].getX(), this.topMargin + this.pos[i].getY(), 20);
         }
      }

      g.setColor(255, 255, 255);
      g.drawString(this.status, this.leftMargin + 1, this.topMargin + 165, 20);
      g.drawString(this.play, this.leftMargin + 1, this.topMargin + 179, 20);
   }

   public void update(char[] board) {
      this.board = board;
      this.repaint();
   }

   public void setStatus(String status) {
      this.status = status;
   }

   public void setPlay(String play) {
      this.play = play;
   }

   public void setKeyReader(IMobileTicTacToeInputReader reader) {
      this.inputReader = reader;
   }

   private class Point {
      private int _x;
      private int _y;

      Point(int x, int y) {
         this._x = x;
         this._y = y;
      }

      public int getX() {
         return this._x;
      }

      public int getY() {
         return this._y;
      }
   }
}

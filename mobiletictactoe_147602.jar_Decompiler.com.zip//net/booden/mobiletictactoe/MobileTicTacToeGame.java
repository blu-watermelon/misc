package net.booden.mobiletictactoe;

public class MobileTicTacToeGame {
   private IMobileTicTacToeGUI gui;
   private IMobileTicTacToePlayType playType;
   private boolean gameEnd = false;
   private char[] board = new char[9];
   private char startPlayer = 'o';
   private char currentPlayer = 'x';
   private char winner = '?';

   public void dispose() {
      if (this.playType != null) {
         this.playType.dispose();
      }

   }

   public MobileTicTacToeGame(IMobileTicTacToeGUI gui, IMobileTicTacToePlayType playType) {
      this.gui = gui;
      this.playType = playType;
      this.playType.setGame(this);
      this.gui.setStatus(playType.getStatus());
      this.gui.setKeyReader(playType);
      this.initGame();
   }

   public boolean isGameEnd() {
      return this.gameEnd;
   }

   public void initGame() {
      for(int i = 0; i < 9; ++i) {
         this.board[i] = '?';
      }

      this.startPlayer = (char)(this.startPlayer == 'x' ? 111 : 120);
      this.currentPlayer = this.startPlayer;
      this.winner = '?';
      this.gameEnd = false;
      this.gui.setStatus(this.playType.getStatus());
      this.gui.setPlay(this.playType.getPlay());
      this.gui.update(this.board);
   }

   public void startFirstGame() {
      for(int i = 0; i < 9; ++i) {
         this.board[i] = '?';
      }

      this.startPlayer = 'x';
      this.currentPlayer = this.startPlayer;
      this.winner = '?';
      this.gameEnd = false;
      this.gui.setStatus(this.playType.getStatus());
      this.gui.setPlay(this.playType.getPlay());
      this.gui.update(this.board);
   }

   public char getWinner() {
      return this.winner;
   }

   public char getCurrentPlayer() {
      return this.currentPlayer;
   }

   public char getBoardValue(int position) {
      return position >= 0 && position < 9 ? this.board[position] : ' ';
   }

   public boolean move(int position) {
      if (position >= 0 && position < 9 && this.board[position] == '?') {
         this.board[position] = this.currentPlayer;
         if (this.checkWin(this.currentPlayer)) {
            this.winner = this.currentPlayer;
            this.gameEnd = true;
         } else {
            boolean check = false;

            for(int j = 0; j < 9 && !check; ++j) {
               if (this.board[j] == '?') {
                  check = true;
               }
            }

            if (!check) {
               this.gameEnd = true;
            }
         }

         this.currentPlayer = (char)(this.currentPlayer == 'x' ? 111 : 120);
         this.gui.setStatus(this.playType.getStatus());
         this.gui.setPlay(this.playType.getPlay());
         this.gui.update(this.board);
         return true;
      } else {
         return false;
      }
   }

   private boolean checkWin(char who) {
      if (this.board[0] == who && this.board[1] == who && this.board[2] == who) {
         return true;
      } else if (this.board[0] == who && this.board[3] == who && this.board[6] == who) {
         return true;
      } else if (this.board[0] == who && this.board[4] == who && this.board[8] == who) {
         return true;
      } else if (this.board[1] == who && this.board[4] == who && this.board[7] == who) {
         return true;
      } else if (this.board[2] == who && this.board[4] == who && this.board[6] == who) {
         return true;
      } else if (this.board[2] == who && this.board[5] == who && this.board[8] == who) {
         return true;
      } else if (this.board[3] == who && this.board[4] == who && this.board[5] == who) {
         return true;
      } else {
         return this.board[6] == who && this.board[7] == who && this.board[8] == who;
      }
   }
}

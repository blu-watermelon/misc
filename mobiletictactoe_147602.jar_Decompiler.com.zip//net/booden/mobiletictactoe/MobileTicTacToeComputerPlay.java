package net.booden.mobiletictactoe;

public class MobileTicTacToeComputerPlay implements IMobileTicTacToePlayType {
   private final char humanPlayer = 'x';
   private final char computerPlayer = 'o';
   private final int keyOffset = 49;
   private MobileTicTacToeGame game;

   public void dispose() {
   }

   public void readKey(int keyCode) {
      int position = keyCode - 49;
      this.processMove(position);
   }

   public void readPointer(int areaNumber) {
      if (this.game.isGameEnd()) {
         this.processMove(-54);
      } else {
         this.processMove(areaNumber);
      }

   }

   private void processMove(int pos) {
      if (this.game != null && (this.game.getCurrentPlayer() == 'x' || this.game.isGameEnd())) {
         if (!this.game.isGameEnd() && pos >= 0 && pos <= 8 && this.game.move(pos) && !this.game.isGameEnd()) {
            this.startComputer();
         }

         if (this.game.isGameEnd() && pos == -54) {
            this.game.initGame();
            if (this.game.getCurrentPlayer() == 'o') {
               this.startComputer();
            }
         }
      }

   }

   public String getStatus() {
      return "Disconnected";
   }

   public String getPlay() {
      if (this.game != null && this.game.isGameEnd()) {
         if (this.game.getWinner() == 'x') {
            return "You win";
         } else {
            return this.game.getWinner() == 'o' ? "You lose" : "No winner this time!";
         }
      } else if (this.game != null) {
         return this.game.getCurrentPlayer() == 'x' ? "Your move" : "Wait for opponents move";
      } else {
         return "Computer play enabled";
      }
   }

   public void setGame(MobileTicTacToeGame game) {
      this.game = game;
   }

   private void startComputer() {
      Thread t = new Thread(new Runnable() {
         public void run() {
            MobileTicTacToeComputerPlay.this.computerMove();
         }
      });
      t.start();
   }

   private void computerMove() {
      try {
         Thread.sleep(1500L);
      } catch (InterruptedException var2) {
      }

      int move = this.calculateMove();
      this.game.move(move);
   }

   private int calculateMove() {
      if (this.game.getBoardValue(4) == '?') {
         return 4;
      } else if (this.game.getBoardValue(0) == '?') {
         return 0;
      } else {
         int win = this.findWin('o');
         if (win != -1) {
            return win;
         } else {
            win = this.findWin('x');
            if (win != -1) {
               return win;
            } else {
               int i;
               for(i = 0; i < 9; i += 2) {
                  if (this.game.getBoardValue(i) == '?') {
                     return i;
                  }
               }

               for(i = 0; i < 9; ++i) {
                  if (this.game.getBoardValue(i) == '?') {
                     return i;
                  }
               }

               return 8;
            }
         }
      }
   }

   public int findWin(char who) {
      int result = this.checkPossibleWin('?', who, who);
      if (result == -1) {
         result = this.checkPossibleWin(who, '?', who);
      }

      if (result == -1) {
         result = this.checkPossibleWin(who, who, '?');
      }

      return result;
   }

   private int checkPossibleWin(char x, char y, char z) {
      if (this.game.getBoardValue(0) == x && this.game.getBoardValue(1) == y && this.game.getBoardValue(2) == z) {
         return x == '?' ? 0 : (y == '?' ? 1 : 2);
      } else if (this.game.getBoardValue(0) == x && this.game.getBoardValue(3) == y && this.game.getBoardValue(6) == z) {
         return x == '?' ? 0 : (y == '?' ? 3 : 6);
      } else if (this.game.getBoardValue(0) == x && this.game.getBoardValue(4) == y && this.game.getBoardValue(8) == z) {
         return x == '?' ? 0 : (y == '?' ? 4 : 8);
      } else if (this.game.getBoardValue(1) == x && this.game.getBoardValue(4) == y && this.game.getBoardValue(7) == z) {
         return x == '?' ? 1 : (y == '?' ? 4 : 7);
      } else if (this.game.getBoardValue(2) == x && this.game.getBoardValue(4) == y && this.game.getBoardValue(6) == z) {
         return x == '?' ? 2 : (y == '?' ? 4 : 6);
      } else if (this.game.getBoardValue(2) == x && this.game.getBoardValue(5) == y && this.game.getBoardValue(8) == z) {
         return x == '?' ? 2 : (y == '?' ? 5 : 8);
      } else if (this.game.getBoardValue(3) == x && this.game.getBoardValue(4) == y && this.game.getBoardValue(5) == z) {
         return x == '?' ? 3 : (y == '?' ? 4 : 5);
      } else if (this.game.getBoardValue(6) == x && this.game.getBoardValue(7) == y && this.game.getBoardValue(8) == z) {
         return x == '?' ? 6 : (y == '?' ? 7 : 8);
      } else {
         return -1;
      }
   }
}
